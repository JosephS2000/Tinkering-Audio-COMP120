﻿using System;

namespace NaughtyAttributes
{
    // The base class for all naughty attributes
    public class NaughtyAttribute : Attribute
    {
    }
}
