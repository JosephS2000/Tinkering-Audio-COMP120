﻿using System;

namespace NaughtyAttributes
{
    public class DrawConditionAttribute : NaughtyAttribute
    {

    }
}
