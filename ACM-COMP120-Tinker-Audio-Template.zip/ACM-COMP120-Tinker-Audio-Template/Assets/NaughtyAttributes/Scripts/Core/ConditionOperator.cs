using System;

namespace NaughtyAttributes
{
    public enum ConditionOperator
    {
        And,
        Or
    }
}
