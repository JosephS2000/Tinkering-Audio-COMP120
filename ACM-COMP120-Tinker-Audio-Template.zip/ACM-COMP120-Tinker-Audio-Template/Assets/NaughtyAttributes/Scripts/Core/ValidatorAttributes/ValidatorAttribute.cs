﻿using System;

namespace NaughtyAttributes
{
    public abstract class ValidatorAttribute : NaughtyAttribute
    {
    }
}
